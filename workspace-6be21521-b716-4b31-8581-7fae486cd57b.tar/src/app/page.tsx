'use client'

import { useState, useEffect } from 'react'
import { Search, Plus, X, Star, Clock, Film, Trash2, ChevronRight } from 'lucide-react'

interface Movie {
  id: string
  title: string
  description: string
  year: number
  rating: number
  posterUrl: string
  duration: number
  director: string
  popularReason: string
  genres: { genre: { name: string } }[]
  scenes: { title: string; timestamp: number; description: string }[]
  similarTo: { similarMovie: { title: string; posterUrl: string }; reason: string }[]
}

interface AddMovieFormProps {
  onAddMovie: (movie: Movie) => void
  onCancel: () => void
}

function AddMovieForm({ onAddMovie, onCancel }: AddMovieFormProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    year: new Date().getFullYear(),
    rating: 7.0,
    posterUrl: '',
    duration: 120,
    director: '',
    popularReason: '',
    genres: '',
    scene1Title: '',
    scene1Timestamp: '',
    scene1Description: '',
    scene2Title: '',
    scene2Timestamp: '',
    scene2Description: '',
    similarMovie: '',
    similarReason: ''
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const newMovie: Movie = {
      id: Date.now().toString(),
      title: formData.title,
      description: formData.description,
      year: formData.year,
      rating: formData.rating,
      posterUrl: formData.posterUrl || 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: formData.duration,
      director: formData.director,
      popularReason: formData.popularReason,
      genres: formData.genres.split(',').map(g => ({ genre: { name: g.trim() } })).filter(g => g.genre.name),
      scenes: [
        ...(formData.scene1Title ? [{
          title: formData.scene1Title,
          timestamp: parseInt(formData.scene1Timestamp) || 0,
          description: formData.scene1Description
        }] : []),
        ...(formData.scene2Title ? [{
          title: formData.scene2Title,
          timestamp: parseInt(formData.scene2Timestamp) || 0,
          description: formData.scene2Description
        }] : [])
      ],
      similarTo: formData.similarMovie ? [{
        similarMovie: {
          title: formData.similarMovie,
          posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300'
        },
        reason: formData.similarReason
      }] : []
    }

    onAddMovie(newMovie)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value
    }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-amber-800 mb-1">Title *</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-amber-800 mb-1">Director *</label>
          <input
            type="text"
            name="director"
            value={formData.director}
            onChange={handleChange}
            className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-amber-800 mb-1">Description *</label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          rows={3}
          className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
          required
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-amber-800 mb-1">Year *</label>
          <input
            type="number"
            name="year"
            value={formData.year}
            onChange={handleChange}
            min="1900"
            max="2030"
            className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-amber-800 mb-1">Rating (0-10) *</label>
          <input
            type="number"
            name="rating"
            value={formData.rating}
            onChange={handleChange}
            min="0"
            max="10"
            step="0.1"
            className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-amber-800 mb-1">Duration (minutes) *</label>
          <input
            type="number"
            name="duration"
            value={formData.duration}
            onChange={handleChange}
            min="1"
            className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-amber-800 mb-1">Poster URL</label>
        <input
          type="url"
          name="posterUrl"
          value={formData.posterUrl}
          onChange={handleChange}
          placeholder="https://example.com/poster.jpg"
          className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-amber-800 mb-1">Genres (comma-separated) *</label>
        <input
          type="text"
          name="genres"
          value={formData.genres}
          onChange={handleChange}
          placeholder="Action, Drama, Thriller"
          className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-amber-800 mb-1">Why It's Popular *</label>
        <textarea
          name="popularReason"
          value={formData.popularReason}
          onChange={handleChange}
          rows={2}
          className="w-full px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
          required
        />
      </div>

      <div className="border-t-2 border-amber-200 pt-4">
        <h4 className="text-lg font-bold text-amber-800 mb-3">Popular Scenes (Optional)</h4>
        <div className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input
              type="text"
              name="scene1Title"
              value={formData.scene1Title}
              onChange={handleChange}
              placeholder="Scene title"
              className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            />
            <input
              type="number"
              name="scene1Timestamp"
              value={formData.scene1Timestamp}
              onChange={handleChange}
              placeholder="Timestamp (seconds)"
              className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            />
            <input
              type="text"
              name="scene1Description"
              value={formData.scene1Description}
              onChange={handleChange}
              placeholder="Scene description"
              className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <input
              type="text"
              name="scene2Title"
              value={formData.scene2Title}
              onChange={handleChange}
              placeholder="Scene title"
              className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            />
            <input
              type="number"
              name="scene2Timestamp"
              value={formData.scene2Timestamp}
              onChange={handleChange}
              placeholder="Timestamp (seconds)"
              className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            />
            <input
              type="text"
              name="scene2Description"
              value={formData.scene2Description}
              onChange={handleChange}
              placeholder="Scene description"
              className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
            />
          </div>
        </div>
      </div>

      <div className="border-t-2 border-amber-200 pt-4">
        <h4 className="text-lg font-bold text-amber-800 mb-3">Similar Movie (Optional)</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <input
            type="text"
            name="similarMovie"
            value={formData.similarMovie}
            onChange={handleChange}
            placeholder="Similar movie title"
            className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
          />
          <input
            type="text"
            name="similarReason"
            value={formData.similarReason}
            onChange={handleChange}
            placeholder="Why they're similar"
            className="px-3 py-2 border-2 border-amber-200 rounded-lg focus:border-amber-400 focus:outline-none"
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 border-2 border-amber-400 text-amber-700 rounded-lg hover:bg-amber-50 transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-6 py-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-all"
        >
          Add Movie
        </button>
      </div>
    </form>
  )
}

export default function Home() {
  const [movies, setMovies] = useState<Movie[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedGenre, setSelectedGenre] = useState('')
  const [showAddForm, setShowAddForm] = useState(false)
  const [loading, setLoading] = useState(true)

  // Sample data for demonstration
  const sampleMovies: Movie[] = [
    {
      id: '1',
      title: 'The Shawshank Redemption',
      description: 'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.',
      year: 1994,
      rating: 9.3,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 142,
      director: 'Frank Darabont',
      popularReason: 'Timeless story of hope and friendship with brilliant performances',
      genres: [{ genre: { name: 'Drama' } }],
      scenes: [
        { title: 'Opera Scene', timestamp: 7200, description: 'Andy plays opera music over the prison PA system' },
        { title: 'Roof Tarring', timestamp: 3600, description: 'Andy helps guards with taxes while prisoners drink beer' }
      ],
      similarTo: [
        { similarMovie: { title: 'The Green Mile', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Prison drama with supernatural elements' }
      ]
    },
    {
      id: '2',
      title: 'Pulp Fiction',
      description: 'The lives of two mob hitmen, a boxer, and a pair of diner bandits intertwine in four tales of violence and redemption.',
      year: 1994,
      rating: 8.9,
      posterUrl: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=300',
      duration: 154,
      director: 'Quentin Tarantino',
      popularReason: 'Revolutionary nonlinear storytelling and iconic dialogue',
      genres: [{ genre: { name: 'Crime' } }, { genre: { name: 'Drama' } }],
      scenes: [
        { title: 'Dance Scene', timestamp: 5400, description: 'Vincent and Mia dance at Jack Rabbit Slims' },
        { title: 'Ezekiel 25:17', timestamp: 1800, description: "Jules' biblical speech before executions" }
      ],
      similarTo: [
        { similarMovie: { title: 'Reservoir Dogs', posterUrl: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=300' }, reason: 'Tarantino\'s debut with similar style' }
      ]
    },
    {
      id: '3',
      title: 'Inception',
      description: 'A thief who steals corporate secrets through dream-sharing technology is given the inverse task of planting an idea.',
      year: 2010,
      rating: 8.8,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 148,
      director: 'Christopher Nolan',
      popularReason: 'Mind-bending plot with stunning visual effects',
      genres: [{ genre: { name: 'Sci-Fi' } }, { genre: { name: 'Action' } }],
      scenes: [
        { title: 'Rotating Hallway', timestamp: 7200, description: 'Zero-gravity fight scene in spinning hallway' },
        { title: 'City Folding', timestamp: 3600, description: 'Paris streets fold onto each other' }
      ],
      similarTo: [
        { similarMovie: { title: 'Interstellar', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Nolan\'s other sci-fi epic' }
      ]
    },
    {
      id: '4',
      title: 'The Dark Knight',
      description: 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.',
      year: 2008,
      rating: 9.0,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 152,
      director: 'Christopher Nolan',
      popularReason: 'Heath Ledger\'s iconic Joker performance and gritty realism',
      genres: [{ genre: { name: 'Action' } }, { genre: { name: 'Crime' } }],
      scenes: [
        { title: 'Bank Heist', timestamp: 300, description: 'Joker orchestrates elaborate bank robbery' },
        { title: 'Pencil Trick', timestamp: 2400, description: 'Joker\'s menacing pencil demonstration' }
      ],
      similarTo: [
        { similarMovie: { title: 'The Dark Knight Rises', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Conclusion to Nolan\'s Batman trilogy' }
      ]
    },
    {
      id: '5',
      title: 'Forrest Gump',
      description: 'The presidencies of Kennedy and Johnson, the Vietnam War, and the Watergate scandal unfold from the perspective of an Alabama man with an IQ of 75.',
      year: 1994,
      rating: 8.8,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 142,
      director: 'Robert Zemeckis',
      popularReason: 'Heartwarming story through major historical events',
      genres: [{ genre: { name: 'Drama' } }, { genre: { name: 'Romance' } }],
      scenes: [
        { title: 'Run Forrest Run', timestamp: 1800, description: 'Forrest breaks free from leg braces' },
        { title: 'Life is Like a Box of Chocolates', timestamp: 600, description: 'Famous bench conversation' }
      ],
      similarTo: [
        { similarMovie: { title: 'The Green Mile', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Tom Hanks in another emotional drama' }
      ]
    },
    {
      id: '6',
      title: 'The Matrix',
      description: 'A computer programmer discovers that reality as he knows it is a simulation created by machines, and joins a rebellion to free humanity.',
      year: 1999,
      rating: 8.7,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 136,
      director: 'The Wachowskis',
      popularReason: 'Revolutionary sci-fi concepts and bullet-time effects',
      genres: [{ genre: { name: 'Sci-Fi' } }, { genre: { name: 'Action' } }],
      scenes: [
        { title: 'Red Pill Blue Pill', timestamp: 4200, description: 'Morpheus offers Neo the choice' },
        { title: 'Bullet Dodge', timestamp: 6300, description: 'Neo dodges bullets in slow motion' }
      ],
      similarTo: [
        { similarMovie: { title: 'Inception', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Mind-bending sci-fi reality questions' }
      ]
    },
    {
      id: '7',
      title: 'Goodfellas',
      description: 'The story of Henry Hill and his life in the mob, covering his relationship with his wife Karen Hill and his mob partners.',
      year: 1990,
      rating: 8.7,
      posterUrl: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=300',
      duration: 146,
      director: 'Martin Scorsese',
      popularReason: 'Masterful mob storytelling with iconic tracking shots',
      genres: [{ genre: { name: 'Crime' } }, { genre: { name: 'Drama' } }],
      scenes: [
        { title: 'Copacabana Tracking Shot', timestamp: 1800, description: 'Famous long shot through nightclub' },
        { title: 'Funny How?', timestamp: 7200, description: 'Tommy\'s menacing interrogation' }
      ],
      similarTo: [
        { similarMovie: { title: 'The Godfather', posterUrl: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=300' }, reason: 'Classic mob saga' }
      ]
    },
    {
      id: '8',
      title: 'Fight Club',
      description: 'An insomniac office worker and a devil-may-care soap maker form an underground fight club that evolves into much more.',
      year: 1999,
      rating: 8.8,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 139,
      director: 'David Fincher',
      popularReason: 'Cult classic with mind-bending twist and social commentary',
      genres: [{ genre: { name: 'Drama' } }, { genre: { name: 'Thriller' } }],
      scenes: [
        { title: 'First Rule of Fight Club', timestamp: 2400, description: 'Tyler explains the rules' },
        { title: 'Project Mayhem', timestamp: 8400, description: 'The chaos begins' }
      ],
      similarTo: [
        { similarMovie: { title: 'Se7en', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Another dark Fincher thriller' }
      ]
    },
    {
      id: '9',
      title: 'The Lord of the Rings: The Fellowship of the Ring',
      description: 'A meek Hobbit and eight companions set out on a journey to destroy the powerful One Ring and save Middle-earth.',
      year: 2001,
      rating: 8.8,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 178,
      director: 'Peter Jackson',
      popularReason: 'Epic fantasy adaptation with groundbreaking visuals',
      genres: [{ genre: { name: 'Fantasy' } }, { genre: { name: 'Adventure' } }],
      scenes: [
        { title: 'Shire Destruction', timestamp: 7200, description: 'Gandalf confronts Saruman' },
        { title: 'Council of Elrond', timestamp: 5400, description: 'Fellowship is formed' }
      ],
      similarTo: [
        { similarMovie: { title: 'The Hobbit', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Middle-earth adventure' }
      ]
    },
    {
      id: '10',
      title: 'Star Wars: Episode IV - A New Hope',
      description: 'Luke Skywalker joins forces with a Jedi Knight, a cocky pilot, a Wookiee and two droids to save the galaxy from the Empire\'s world-destroying battle station.',
      year: 1977,
      rating: 8.6,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 121,
      director: 'George Lucas',
      popularReason: 'Original space opera that changed cinema forever',
      genres: [{ genre: { name: 'Sci-Fi' } }, { genre: { name: 'Adventure' } }],
      scenes: [
        { title: 'Cantina Scene', timestamp: 4200, description: 'Iconic Mos Eisley cantina' },
        { title: 'Trench Run', timestamp: 6600, description: 'Death Star battle finale' }
      ],
      similarTo: [
        { similarMovie: { title: 'The Empire Strikes Back', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Dark sequel to the original' }
      ]
    },
    {
      id: '11',
      title: 'The Avengers',
      description: 'Earth\'s mightiest heroes must come together and learn to fight as a team if they are going to stop the mischievous Loki and his alien army from enslaving humanity.',
      year: 2012,
      rating: 8.0,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 143,
      director: 'Joss Whedon',
      popularReason: 'First superhero team-up with iconic Marvel characters',
      genres: [{ genre: { name: 'Action' } }, { genre: { name: 'Sci-Fi' } }],
      scenes: [
        { title: 'Battle of New York', timestamp: 7200, description: 'Heroes assemble against alien invasion' },
        { title: 'Shawarma Scene', timestamp: 8400, description: 'Post-battle team meal' }
      ],
      similarTo: [
        { similarMovie: { title: 'Avengers: Endgame', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Epic conclusion to the saga' }
      ]
    },
    {
      id: '12',
      title: 'The Godfather',
      description: 'The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.',
      year: 1972,
      rating: 9.2,
      posterUrl: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=300',
      duration: 175,
      director: 'Francis Ford Coppola',
      popularReason: 'Masterpiece of American cinema with iconic performances',
      genres: [{ genre: { name: 'Crime' } }, { genre: { name: 'Drama' } }],
      scenes: [
        { title: 'Horse Head', timestamp: 3600, description: 'Iconic wake-up call scene' },
        { title: 'Offer He Can\'t Refuse', timestamp: 1800, description: 'Vito\'s famous threat' }
      ],
      similarTo: [
        { similarMovie: { title: 'Goodfellas', posterUrl: 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=300' }, reason: 'Another mob classic' }
      ]
    },
    {
      id: '13',
      title: 'The Silence of the Lambs',
      description: 'A young FBI cadet must receive the help of an incarcerated and manipulative cannibal killer to help catch another serial killer.',
      year: 1991,
      rating: 8.6,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 118,
      director: 'Jonathan Demme',
      popularReason: 'Terrifying psychological thriller with Oscar-winning performances',
      genres: [{ genre: { name: 'Thriller' } }, { genre: { name: 'Crime' } }],
      scenes: [
        { title: 'Hello Clarice', timestamp: 1200, description: 'First meeting with Lecter' },
        { title: 'Quid Pro Quo', timestamp: 3600, description: 'The famous deal-making scene' }
      ],
      similarTo: [
        { similarMovie: { title: 'Se7en', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Dark psychological thriller' }
      ]
    },
    {
      id: '14',
      title: 'Schindler\'s List',
      description: 'In German-occupied Poland during World War II, industrialist Oskar Schindler gradually becomes concerned for his Jewish workforce.',
      year: 1993,
      rating: 9.0,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 195,
      director: 'Steven Spielberg',
      popularReason: 'Powerful Holocaust drama with historical significance',
      genres: [{ genre: { name: 'Drama' } }, { genre: { name: 'History' } }],
      scenes: [
        { title: 'Girl in Red Coat', timestamp: 7200, description: 'Symbolic color scene' },
        { title: 'I Could Have Done More', timestamp: 10800, description: 'Schindler\'s emotional breakdown' }
      ],
      similarTo: [
        { similarMovie: { title: 'Life is Beautiful', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Holocaust story with hope' }
      ]
    },
    {
      id: '15',
      title: 'Interstellar',
      description: 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival.',
      year: 2014,
      rating: 8.6,
      posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300',
      duration: 169,
      director: 'Christopher Nolan',
      popularReason: 'Epic space exploration with scientific accuracy and emotion',
      genres: [{ genre: { name: 'Sci-Fi' } }, { genre: { name: 'Drama' } }],
      scenes: [
        { title: 'Tesseract Scene', timestamp: 9600, description: '5D communication through time' },
        { title: 'Docking Scene', timestamp: 7200, description: 'Intense space docking sequence' }
      ],
      similarTo: [
        { similarMovie: { title: '2001: A Space Odyssey', posterUrl: 'https://images.unsplash.com/photo-1489599136584-596636715c0c?w=300' }, reason: 'Classic space exploration' }
      ]
    }
  ]

  useEffect(() => {
    // Load sample data for now
    setTimeout(() => {
      setMovies(sampleMovies)
      setLoading(false)
    }, 1000)
  }, [])

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`
  }

  const formatTimestamp = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const filteredMovies = movies.filter(movie => {
    const matchesSearch = movie.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         movie.director.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         movie.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesGenre = !selectedGenre || movie.genres.some(g => g.genre.name === selectedGenre)
    return matchesSearch && matchesGenre
  })

  const allGenres = Array.from(new Set(movies.flatMap(m => m.genres.map(g => g.genre.name))))

  const removeMovie = (id: string) => {
    setMovies(movies.filter(m => m.id !== id))
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 flex items-center justify-center">
        <div className="text-center">
          <Film className="w-16 h-16 mx-auto mb-4 text-amber-600 animate-pulse" />
          <p className="text-2xl font-bold text-amber-800">Loading Retro Cinema...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100">
      {/* Retro Header */}
      <header className="bg-gradient-to-r from-amber-600 to-orange-600 shadow-lg border-b-4 border-amber-800">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center mb-6">
            <h1 className="text-5xl font-bold text-white mb-2" style={{ fontFamily: 'Georgia, serif', textShadow: '3px 3px 6px rgba(0,0,0,0.5)' }}>
              🎬 RETRO CINEMA 🎬
            </h1>
            <p className="text-amber-100 text-lg">Discover Timeless Films & Hidden Gems</p>
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-amber-300 w-5 h-5" />
              <input
                type="text"
                placeholder="Search movies, directors, or keywords..."
                className="w-full pl-12 pr-4 py-3 rounded-full border-2 border-amber-400 bg-white/90 backdrop-blur text-amber-900 placeholder-amber-400 focus:outline-none focus:border-amber-500 focus:bg-white transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Genre Filter */}
          <div className="flex justify-center mt-4 gap-2 flex-wrap">
            <button
              onClick={() => setSelectedGenre('')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                !selectedGenre 
                  ? 'bg-amber-800 text-white' 
                  : 'bg-amber-200 text-amber-800 hover:bg-amber-300'
              }`}
            >
              All Genres
            </button>
            {allGenres.map(genre => (
              <button
                key={genre}
                onClick={() => setSelectedGenre(genre)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedGenre === genre 
                    ? 'bg-amber-800 text-white' 
                    : 'bg-amber-200 text-amber-800 hover:bg-amber-300'
                }`}
              >
                {genre}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Add Movie Button */}
        <div className="text-center mb-8">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-6 py-3 rounded-full font-bold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all flex items-center gap-2 mx-auto"
          >
            <Plus className="w-5 h-5" />
            Add New Movie
          </button>
        </div>

        {/* Add Movie Form */}
        {showAddForm && (
          <div className="bg-white rounded-xl shadow-xl p-6 mb-8 border-4 border-amber-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-2xl font-bold text-amber-800">Add New Movie</h3>
              <button
                onClick={() => setShowAddForm(false)}
                className="text-amber-600 hover:text-amber-800"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <AddMovieForm 
              onAddMovie={(newMovie) => {
                setMovies([...movies, newMovie])
                setShowAddForm(false)
              }}
              onCancel={() => setShowAddForm(false)}
            />
          </div>
        )}

        {/* Movies Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMovies.map(movie => (
            <div
              key={movie.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden border-4 border-amber-200 hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              {/* Movie Poster */}
              <div className="relative h-64 bg-gradient-to-br from-amber-100 to-orange-100">
                <img
                  src={movie.posterUrl}
                  alt={movie.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 bg-amber-600 text-white px-2 py-1 rounded-full flex items-center gap-1">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="text-sm font-bold">{movie.rating}</span>
                </div>
                <button
                  onClick={() => removeMovie(movie.id)}
                  className="absolute top-2 left-2 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Movie Info */}
              <div className="p-4">
                <h3 className="text-xl font-bold text-amber-900 mb-1">{movie.title}</h3>
                <p className="text-amber-700 text-sm mb-2">{movie.year} • {movie.director} • {formatTime(movie.duration)}</p>
                
                {/* Genres */}
                <div className="flex gap-1 flex-wrap mb-3">
                  {movie.genres.map((g, idx) => (
                    <span key={idx} className="bg-amber-200 text-amber-800 px-2 py-1 rounded-full text-xs font-medium">
                      {g.genre.name}
                    </span>
                  ))}
                </div>

                {/* Description */}
                <p className="text-gray-700 text-sm mb-3 line-clamp-3">{movie.description}</p>

                {/* Why Popular */}
                <div className="bg-amber-50 rounded-lg p-3 mb-3">
                  <p className="text-xs font-bold text-amber-800 mb-1">Why It's Popular:</p>
                  <p className="text-xs text-amber-700">{movie.popularReason}</p>
                </div>

                {/* Popular Scenes */}
                {movie.scenes.length > 0 && (
                  <div className="mb-3">
                    <p className="text-xs font-bold text-amber-800 mb-2">Popular Scenes:</p>
                    <div className="space-y-1">
                      {movie.scenes.map((scene, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs">
                          <Clock className="w-3 h-3 text-amber-600" />
                          <span className="text-amber-700 font-medium">{formatTimestamp(scene.timestamp)}</span>
                          <ChevronRight className="w-3 h-3 text-gray-400" />
                          <span className="text-gray-700">{scene.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Similar Movies */}
                {movie.similarTo.length > 0 && (
                  <div>
                    <p className="text-xs font-bold text-amber-800 mb-2">Similar Movies:</p>
                    <div className="flex gap-2">
                      {movie.similarTo.map((similar, idx) => (
                        <div key={idx} className="flex-1 text-center">
                          <div className="w-12 h-16 bg-gradient-to-br from-amber-100 to-orange-100 rounded mb-1 mx-auto"></div>
                          <p className="text-xs text-gray-700 truncate">{similar.similarMovie.title}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {filteredMovies.length === 0 && (
          <div className="text-center py-12">
            <Film className="w-16 h-16 mx-auto mb-4 text-amber-300" />
            <p className="text-xl text-amber-700">No movies found matching your criteria</p>
          </div>
        )}
      </main>

      {/* Retro Footer */}
      <footer className="bg-gradient-to-r from-amber-800 to-orange-800 text-white py-8 mt-12 border-t-4 border-amber-900">
        <div className="container mx-auto px-4 text-center">
          <p className="text-lg mb-2" style={{ fontFamily: 'Georgia, serif' }}>🎬 Retro Cinema 🎬</p>
          <p className="text-amber-200">Your Gateway to Timeless Cinema</p>
        </div>
      </footer>
    </div>
  )
}